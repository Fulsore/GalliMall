'use client';

const AboutPage = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-4 text-blue-600">About GalliMall</h1>
      <p className="mb-6 text-lg">
        GalliMall is a revolutionary hyperlocal marketplace that connects nearby vendors and customers to empower local business through technology.
      </p>

      <h2 className="text-xl font-semibold mt-8 mb-2">Founders & Developers</h2>
      <ul className="space-y-2 list-disc ml-5 text-base">
        <li><strong>Anil</strong> – Founder & CEO of GalliMall</li>
        <li><strong>Ramu</strong> – Co-founder & Lead Developer</li>
        <li><strong>Team GalliMall</strong> – UI/UX, marketing, tech, and support contributors</li>
      </ul>

      <h2 className="text-xl font-semibold mt-10 mb-2">Our Journey</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <img src="/images/journey1.jpg" alt="Team at work" className="rounded-md shadow" />
        <img src="/images/journey2.jpg" alt="Local vendor onboarding" className="rounded-md shadow" />
        <video controls className="rounded-md shadow">
          <source src="/videos/gallimall-intro.mp4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
    </div>
  );
};

export default AboutPage;
