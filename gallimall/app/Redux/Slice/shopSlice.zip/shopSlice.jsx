import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

const API = process.env.NEXT_PUBLIC_API_BASE_URL;

// 🔁 Create Shop
export const createShop = createAsyncThunk(
  'shop/createShop',
  async (shopData, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.post(`${API}/shops/`, shopData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// ✅ Fetch Public Shop Details
export const fetchShopDetails = createAsyncThunk(
  'shop/fetchShopDetails',
  async (shopId, { rejectWithValue }) => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.get(`${API}/shops/${shopId}/public-details/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.detail || 'Failed to fetch shop details'
      );
    }
  }
);

// 📍 Fetch Nearest Shop ID
export const fetchNearestShopId = createAsyncThunk(
  'shop/fetchNearestShopId',
  async ({ lat, lon }, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API}/shops/nearest/`, {
        params: { lat, lon },
      });
      return response.data.shopId;
    } catch (error) {
      return rejectWithValue(error.response?.data?.detail || 'Failed to get nearest shop');
    }
  }
);

// 🔧 Slice
const shopSlice = createSlice({
  name: 'shop',
  initialState: {
    shop: null,
    categories: [],
    subcategories: [],
    products: [],
    nearestShopId: null,
    loading: false,
    error: null,
    success: false,
  },
  reducers: {
    resetShopState: (state) => {
      state.shop = null;
      state.categories = [];
      state.subcategories = [];
      state.products = [];
      state.nearestShopId = null;
      state.loading = false;
      state.error = null;
      state.success = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(createShop.pending, (state) => {
        state.loading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(createShop.fulfilled, (state, action) => {
        state.loading = false;
        state.shop = action.payload;
        state.success = true;
      })
      .addCase(createShop.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
        state.success = false;
      })
      .addCase(fetchShopDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchShopDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.shop = action.payload.shop;
        state.categories = action.payload.categories;
        state.subcategories = action.payload.subcategories;
        state.products = action.payload.products;
      })
      .addCase(fetchShopDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || 'Something went wrong';
      })
      .addCase(fetchNearestShopId.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchNearestShopId.fulfilled, (state, action) => {
        state.loading = false;
        state.nearestShopId = action.payload;
      })
      .addCase(fetchNearestShopId.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { resetShopState } = shopSlice.actions;
export default shopSlice.reducer;