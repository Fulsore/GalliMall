'use client';

import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import Image from "next/image";
import Hero from "../../Components/Hero/HeroSlider";
import Category from "../../Category/Customer/page";
import axios from "axios";
import Product from "../../product/customer/product/page";

export default function CustomerDashboard() {
  const user = useSelector((state) => state.user);
  const router = useRouter();
  const backendBaseUrl = "http://127.0.0.1:8000";

  const [products, setProducts] = useState([]);
  const [suggestedProducts, setSuggestedProducts] = useState([]);
  const [shops, setShops] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [loadingShops, setLoadingShops] = useState(true);
  const [error, setError] = useState(null);

  const [promotions, setPromotions] = useState([]);


  useEffect(() => {
  async function fetchPromotions() {
    try {
      const res = await axios.get(`${backendBaseUrl}/api/promotions/`);
      setPromotions(res.data);
    } catch (err) {
      console.error("Failed to fetch promotions", err);
    }
  }

  fetchPromotions();
}, []);


  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await fetch(`${backendBaseUrl}/api/subcategory/`);
        if (!res.ok) throw new Error("Failed to fetch products");
        const data = await res.json();
        setProducts(data);
        setSuggestedProducts(data.slice(0, 3));
      } catch (err) {
        setError(err.message);
      } finally {
        setLoadingProducts(false);
      }
    }
    fetchProducts();
  }, []);

  useEffect(() => {
    async function fetchShops() {
      try {
        const token = localStorage.getItem('access_token');
        const response = await axios.get(`${backendBaseUrl}/api/shops/`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setShops(response.data.results);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoadingShops(false);
      }
    }
    fetchShops();
  }, []);

  const handleRedirect = (route) => {
    router.push(route);
  };

  const featuredItems = [
    {
      id: 1,
      name: "Electronic Shop",
      image: "/images/e_shop.jpg", // ✅ static public image
      route: "/Category/1",
    },
    {
      id: 2,
      name: "Dairy",
      image: "/images/Dairy.jpg",
      route: "/category/pharmacy",
    },
    {
      id: 3,
      name: "Bakery Specials",
      image: "/images/Food.jpg",
      route: "/category/bakery",
    },
    {
      id: 4,
      name: "Grocery",
      image: "/images/Grosery.jpg",
      route: "/category/fashion",
    },
  ];

  const renderCarouselItems = (
    items,
    imageKey,
    nameKey,
    clickRouteKey,
    fallbackImage = "/images/b_shop.jpg"
  ) => (
    <div className="flex gap-6 overflow-x-auto no-scrollbar py-2 px-1">
      {items.map((item) => {
        const imagePath = item[imageKey];
        const imageUrl = imagePath
  ? imagePath.startsWith("http")
    ? imagePath
    : imagePath.startsWith("/")
      ? `${backendBaseUrl}${imagePath}`
      : `https://res.cloudinary.com/GalliMall_Images/image/upload/${imagePath}`
  : fallbackImage;


        return (
          <motion.div
            key={item.id}
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }}
            onClick={() =>
              handleRedirect(
                typeof clickRouteKey === "function"
                  ? clickRouteKey(item)
                  : item[clickRouteKey]
              )
            }
            className="min-w-[90px] sm:min-w-[100px] cursor-pointer flex flex-col items-center hover:shadow-md"
          >
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full overflow-hidden border border-gray-300">
              <Image
                src={imageUrl || fallbackImage}
                alt={item[nameKey] || 'Image'} 
                width={96}
                height={96}
                className="w-full h-full object-cover"
                unoptimized
              />
            </div>
            <p className="mt-2 text-sm text-gray-700 font-medium text-center w-full truncate">
              {item[nameKey]}
            </p>
          </motion.div>
        );
      })}
    </div>
  );

  return (
    <main className="bg-gradient-to-br from-[#f8f9fa] to-[#f1f3f5] min-h-screen">
      <Hero />
      <div className="px-4 sm:px-6 md:px-10 py-6 space-y-10">
        <Category />

        {/* Shops */}
        <section>
          <h2 className="text-2xl font-bold mb-3 text-gray-800">🧭 All Shops</h2>
          {loadingShops && <p>Loading shops...</p>}
          {error && <p className="text-red-500">{error}</p>}
          {!loadingShops &&
            !error &&
            renderCarouselItems(
              shops,
              "shop_image",
              "name",
              (item) => `/RoleDash/Customer/shop?shopId=${item.id}`
            )}
        </section>

        {/* Promotions */}
        <section>
          <h2 className="text-2xl font-bold mb-3 text-gray-800">⭐ Promotions</h2>
          {renderCarouselItems(featuredItems, "image", "name", "route")}
        </section>

        {/* Popular Near You */}
        {/* <section>
          <h2 className="text-2xl font-bold mb-3 text-gray-800">🎯 Popular Near You</h2>
          {loadingProducts && <p>Loading...</p>}
          {error && <p className="text-red-500">{error}</p>}
          {!loadingProducts &&
            !error &&
            renderCarouselItems(
              products.slice(0, 6),
              "image",
              "name",
              (item) => `/product/${item.id}`
            )}
        </section> */}

        {/* Suggestions */}
        {/* <section>
          <h2 className="text-2xl font-bold mb-3 text-gray-800">💡 Smart Suggestions</h2>
          {!loadingProducts &&
            !error &&
            renderCarouselItems(
              suggestedProducts,
              "image",
              "name",
              (item) => `/subcategory/${item.id}`
            )}
        </section> */}

        <section>
          <Product />
        </section>
      </div>
    </main>
  );
}
