'use client';

import React, { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { LoaderCircle } from 'lucide-react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchShopDetails,
  fetchNearestShopId,
} from '../../../Redux/Slice/shopSlice';
import { addToCart } from '../../../Redux/Slice/cartSlice';

const FloatingCartBar = ({ quantities, products }) => {
  const router = useRouter();

  const selectedItems = products.filter(p => quantities[p.id]);
  const totalItems = selectedItems.reduce((sum, item) => sum + quantities[item.id], 0);
  const totalPrice = selectedItems.reduce((sum, item) => sum + item.price * quantities[item.id], 0);

  if (totalItems === 0) return null;

  const handleViewCart = () => {
    localStorage.setItem('cartItems', JSON.stringify(selectedItems));
    localStorage.setItem('cartQuantities', JSON.stringify(quantities));
    localStorage.setItem('cartTotal', JSON.stringify(totalPrice));
    router.push('/cart');
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t p-4 shadow-md flex justify-between items-center">
      <div>
        <p className="text-sm text-gray-700 font-medium">
          {totalItems} item(s) | ₹{totalPrice.toFixed(2)}
        </p>
        <p className="text-xs text-gray-500">Extra charges may apply</p>
      </div>
      <button
        onClick={handleViewCart}
        className="bg-blue-600 text-white px-4 py-2 rounded-full font-semibold hover:bg-blue-700"
      >
        View Cart
      </button>
    </div>
  );
};

const ShopPage = () => {
  const searchParams = useSearchParams();
  const shopIdQuery = searchParams.get('shopId');
  const dispatch = useDispatch();
  const router = useRouter();

  const {
    shop,
    categories,
    subcategories,
    products,
    nearestShopId,
    loading,
    error,
  } = useSelector((state) => state.shop);

  const token = useSelector((state) => state.auth.token);
  const cart_code = useSelector((state) => state.cart.cart_code);
  const [quantities, setQuantities] = useState({});

  // Geolocation fetch logic
  useEffect(() => {
    if (shopIdQuery) {
      dispatch(fetchShopDetails(shopIdQuery));
    } else {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const { latitude, longitude } = pos.coords;
            dispatch(fetchNearestShopId({ lat: latitude, lon: longitude }));
          },
          (err) => {
            console.error('Geolocation Error:', err);
          }
        );
      }
    }
  }, [shopIdQuery, dispatch]);

  useEffect(() => {
    if (!shopIdQuery && nearestShopId) {
      dispatch(fetchShopDetails(nearestShopId));
      router.replace(`/RoleDash/Customer/shop?shopId=${nearestShopId}`);
    }
  }, [nearestShopId, shopIdQuery, dispatch, router]);

  const handleAddToCart = (product) => {
    const updatedQty = 1;
    setQuantities((prev) => ({ ...prev, [product.id]: updatedQty }));

    dispatch(addToCart({
      productId: product.id,
      quantity: updatedQty,
      token,
      cart_code
    }));
  };

  const increment = (productId) => {
    const newQty = (quantities[productId] || 0) + 1;
    setQuantities((prev) => ({ ...prev, [productId]: newQty }));

    dispatch(addToCart({
      productId,
      quantity: 1,
      token,
      cart_code
    }));
  };

  const decrement = (productId) => {
    const current = quantities[productId] || 0;
    const newQty = current - 1;
    if (newQty <= 0) {
      const updated = { ...quantities };
      delete updated[productId];
      setQuantities(updated);
    } else {
      setQuantities((prev) => ({ ...prev, [productId]: newQty }));

      dispatch(addToCart({
        productId,
        quantity: -1,
        token,
        cart_code
      }));
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <LoaderCircle className="animate-spin h-8 w-8 text-blue-600" />
        <span className="ml-2">Loading shop details...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-600 text-center mt-10">
        ❌ Error: {error}
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto pb-24">
      <h1 className="text-2xl font-bold mb-1">{shop?.shop_name}</h1>
      <p className="text-gray-700">{shop?.shop_description}</p>
      <p className="text-sm text-gray-500 mt-1">
        📍 {shop?.shop_address} | 📞 {shop?.shop_phone_number}
      </p>

      <h2 className="text-xl font-semibold mt-6 mb-2">🛒 Products</h2>
      {products.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((product) => {
            const quantity = quantities[product.id] || 0;
            return (
              <div
                key={product.id}
                className="border p-4 rounded-xl shadow hover:shadow-lg transition bg-white"
              >
                <img
                  src={product.image || '/placeholder.png'}
                  alt={product.name}
                  className="w-full h-32 object-cover mb-2 rounded"
                />
                <h3 className="font-semibold">{product.name}</h3>
                <p className="text-gray-600 text-sm">{product.description}</p>
                <p className="mt-1 font-bold text-green-700">₹{product.price}</p>

                <div className="mt-2">
                  {quantity === 0 ? (
                    <button
                      onClick={() => handleAddToCart(product)}
                      className="bg-blue-500 text-white text-sm px-3 py-1 rounded hover:bg-blue-600"
                    >
                      + Add
                    </button>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => decrement(product.id)}
                        className="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 text-lg"
                      >
                        −
                      </button>
                      <span className="font-semibold text-gray-800">{quantity}</span>
                      <button
                        onClick={() => increment(product.id)}
                        className="bg-green-500 text-white px-2 py-1 rounded hover:bg-green-600 text-lg"
                      >
                        +
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <p className="text-sm text-gray-500 ml-2">No products listed yet.</p>
      )}

      {/* Floating View Cart Bar */}
      <FloatingCartBar quantities={quantities} products={products} />
    </div>
  );
};

export default ShopPage;
