import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";

export default function ChatPage() {
  const [input, setInput] = useState("");
  const [chat, setChat] = useState([]);
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setChat((prev) => [...prev, { type: "user", text: userMsg }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch(process.env.REACT_APP_CHAT_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg }),
      });

      const data = await res.json();
      setChat((prev) => [
        ...prev,
        { type: "bot", text: data.reply || "Sorry, I didn't get that." },
      ]);
    } catch (error) {
      setChat((prev) => [
        ...prev,
        { type: "bot", text: "⚠️ Failed to fetch response." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") sendMessage();
  };

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat, loading]);

  return (
    <div
      className="min-vh-100 d-flex align-items-center justify-content-center"
      style={{
        backgroundImage: "url('/background1.jpg')", // ✅ Background image from public folder
        backgroundSize: "cover",
        backgroundPosition: "center",
        padding: "30px",
      }}
    >
      <div
        className="card shadow-lg"
        style={{
          maxWidth: "600px",
          width: "100%",
          borderRadius: "20px",
          background: "rgba(255,255,255,0.9)",
        }}
      >
        <div className="card-body">
          {/* ✅ Bot avatar */}
          <div className="text-center mb-3">
            <img
              src="/bot.jpg" // ✅ No import needed, directly from public
              alt="AI Bot"
              style={{ width: "100px", height: "100px", borderRadius: "50%" }}
            />
          </div>

          <h3 className="text-center fw-bold">🤖 AI Chatbot</h3>

          <div
            className="border rounded p-3 mb-3"
            style={{
              height: "400px",
              overflowY: "auto",
              background: "#f9f9f9",
            }}
          >
            {chat.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`p-2 rounded mb-2 ${
                  msg.type === "user"
                    ? "bg-primary text-white ms-auto"
                    : "bg-light text-dark me-auto"
                }`}
                style={{ maxWidth: "70%" }}
              >
                {msg.text}
              </motion.div>
            ))}
            {loading && (
              <motion.div
                className="text-muted fst-italic small"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Bot is typing...
              </motion.div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="input-group">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              className="form-control"
              placeholder="Type your message..."
            />
            <motion.button
              onClick={sendMessage}
              whileTap={{ scale: 0.95 }}
              className="btn btn-primary"
            >
              Send
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}
